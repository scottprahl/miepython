"""
Mie scattering calculations for perfect spheres.

Extensive documentation is at <https://miepython.readthedocs.io>

`miepython` is a pure Python module to calculate light scattering of
a plane wave by non-absorbing, partially-absorbing, or perfectly conducting
spheres.

The extinction efficiency, scattering efficiency, backscattering, and
scattering asymmetry for a sphere with complex index of refraction m,
diameter d, and wavelength lambda can be found by::

    import miepython as mie
    qext, qsca, qback, g = mie.efficiencies(m, d, lambda0)

The normalized scattering values for angles mu=cos(theta) are::

    Ipar, Iper = mie.intensities(m, d, lambda0, mu)

If the size parameter is known, then use::

    mie.efficiencies_mx(m, x)

Mie scattering amplitudes S1 and S2 (complex numbers):

    mie.S1_S2(m, x, mu)

Normalized Mie scattering intensities for angles mu=cos(theta)::

    mie.i_per(m, x, mu)
    mie.i_par(m, x, mu)
    mie.i_unpolarized(m, x, mu)
"""

import numpy as np
from ._backend import _S1_S2, an_bn, cn_dn, single_sphere
from ._convention import _convert

# not really needed but included for clarity
__all__ = (
    "intensities",
    "i_par",
    "i_per",
    "i_unpolarized",
    "efficiencies_mx",
    "efficiencies",
    "S1_S2",
    "phase_matrix",
    "coefficients",
    "wiscombe_terms",
    "normalization_factor",
)


def wiscombe_terms(x):
    """
    Return the number of Mie series terms from Wiscombe's criterion.

    The series is truncated after this many orders so that the summed scattering
    quantities are accurate to about 1e-6.  The low-level ``an_bn`` and ``cn_dn``
    kernels repeat this expression because numba cannot call back into Python.

    Args:
        x: the size parameter of the sphere

    Returns:
        number of terms, so orders 1 through the returned value
    """
    return int(x + 4.05 * x**0.33333 + 2.0)


def _check_m_x(m, x):
    """
    Reject an index or size parameter that the kernels would silently misread.

    The kernels treat any index whose real part fails ``m.real > 0`` as a perfect
    conductor, so a NaN or negative real part gave the answer for a metal sphere
    instead of an error.  A NaN or infinite x failed differently on each backend.

    Args:
        m: refractive index of the sphere, scalar or array
        x: size parameter of the sphere, scalar or array

    Raises:
        ValueError: if m or x is not finite, x is negative, or m.real is negative
    """
    m = np.asarray(m)
    x = np.asarray(x)
    if not np.all(np.isfinite(m)):
        raise ValueError(f"refractive index must be finite, got m={m}")
    if np.any(m.real < 0):
        raise ValueError(
            f"real part of the refractive index must not be negative, got m={m}; "
            "use m.real == 0 for a perfect conductor"
        )
    if not np.all(np.isfinite(x)):
        raise ValueError(f"size parameter must be finite, got x={x}")
    if np.any(x < 0):
        raise ValueError(f"size parameter must not be negative, got x={x}")


def _check_one_sphere(m, x):
    """
    Reject arrays of m or x in functions that describe a single sphere.

    The angular functions vectorize over mu, so an array of spheres has no
    unambiguous shape to return.  Without this check numpy raised "truth value of
    an array is ambiguous" from deep inside.

    Args:
        m: refractive index of the sphere
        x: size parameter of the sphere

    Raises:
        ValueError: if m or x is not a scalar
    """
    if np.ndim(m) > 0 or np.ndim(x) > 0:
        raise ValueError("this function takes one sphere, so m and x must be scalars; loop over spheres for more")


def _scalarize_0d(value):
    """Pass a zero-dimensional NumPy array to scalar kernels as a scalar."""
    return value.item() if isinstance(value, np.ndarray) and value.ndim == 0 else value


def coefficients(m, x, n_pole=0, internal=False):
    """
    Computes the Mie coefficients for a sphere.

    This function calculates the Mie coefficients for electromagnetic scattering
    by a sphere. It supports both single values and arrays for the refractive
    index and size parameter. For arrays, the lengths of `m` and `x` must match.
    Zero-dimensional NumPy arrays are treated as scalar values.

    If `n_pole > 0`, the function returns the coefficients of orders 1 through
    `n_pole` for each input, so the last entry is the order-`n_pole` term.  This
    differs from `efficiencies_mx` and `S1_S2`, where a nonzero `n_pole` isolates
    that single order.

    Args:
        m (complex or array-like): The complex refractive index of the sphere.
            If an array, must match the length of `x`.
        x (float or array-like): The size parameter of the sphere. If an array,
            must match the length of `m`.
        n_pole (int, optional): The number of orders to compute, 1 through
            `n_pole`.  Defaults to 0, which uses Wiscombe's criterion for the
            number of terms.
        internal (bool, optional): If True then returns Mie coefficients needed to
            calculate fields inside the sphere.

    Returns:
        ndarray: ``[a, b]``, or ``[a, b, c, d]`` when ``internal`` is True.  For
            scalar ``m`` and ``x`` each entry is a 1-D array of coefficients, so
            the result has shape ``(2, n_terms)`` or ``(4, n_terms)``.  For array
            input each entry gains a leading axis over the spheres, giving
            ``(2, n_spheres, n_pole)`` or ``(4, n_spheres, n_pole)``.

    Notes:
        - If the imaginary part of the refractive index is positive, it is
          automatically corrected to its conjugate value to ensure a valid input.
        - The coefficients follow the active time convention (see
          ``miepython.set_time_convention``).  With the default exp(+jωt) they
          are the conjugates of Bohren & Huffman's a_n and b_n; inside
          ``miepython.time_convention("-")`` they are Bohren & Huffman's own.
        - Every returned coefficient is a real term; the arrays carry no padding.

    Raises:
        ValueError: if m or x is not finite, x is negative, or the real part of
            m is negative.  A perfect conductor is m.real == 0, not m.real < 0.

    Examples:
        Compute coefficients for a single sphere:

        >>> import miepython as mie
        >>> a, b = mie.coefficients(1.5 - 0.1j, 0.1)
        >>> len(a), len(b)
        (3, 3)
        >>> print(f"{a[0]:.6e}")
        3.333700e-05+1.973631e-04j
        >>> print(f"{b[0]:.6e}")
        6.672963e-08+2.754694e-07j

        Keep only the dipole term for each of several spheres:

        >>> a, b = mie.coefficients([1.5 - 0.1j, 1.4 - 0.05j], [2.0, 1.8], n_pole=1)
        >>> a.shape
        (2, 1)
        >>> print(f"{a[0, 0]:.6f}")
        0.447946+0.386652j
    """
    return _convert(_coefficients(m, x, n_pole, internal))


def _coefficients(m, x, n_pole=0, internal=False):
    """Return ``coefficients`` in exp(-iωt), whatever the active convention."""
    _check_m_x(m, x)
    m, x = _scalarize_0d(m), _scalarize_0d(x)
    mlen = np.size(m) if np.ndim(m) > 0 else 0
    xlen = np.size(x) if np.ndim(x) > 0 else 0

    if mlen == 0 and xlen == 0:
        a, b = an_bn(m, x, n_pole)
        if internal:
            c, d = cn_dn(m, x, n_pole)

    else:
        if xlen > 0 and mlen > 0 and xlen != mlen:
            raise RuntimeError("m and x arrays must be same length")

        if n_pole == 0:
            raise RuntimeError("when m or x is an array then n_pole must be >0")

        thelen = max(xlen, mlen)

        a = [None] * thelen
        b = [None] * thelen
        if internal:
            c = [None] * thelen
            d = [None] * thelen

        for i in range(thelen):
            mm = m[i] if mlen > 0 else m
            xx = x[i] if xlen > 0 else x

            a[i], b[i] = an_bn(mm, xx, n_pole)
            if internal:
                c[i], d[i] = cn_dn(mm, xx, n_pole)

    if internal:
        return np.array([a, b, c, d])
    return np.array([a, b])


def efficiencies_mx(m, x, n_pole=0, e_field=True):
    """
    Computes scattering and extinction efficiencies for a spherical particle using Mie theory.

    Supports array inputs for wavelength-dependent calculations of the refractive index
    and size parameter.

    Args:
        m (complex or array-like):
            Complex refractive index of the sphere, defined as m = n - ik,
            where n is the real part (phase velocity) and k is the
            imaginary part (absorption). Can be a scalar or an array.
        x (float or array-like):
            Size parameter of the sphere, defined as x = π d / λ,
            where d is the diameter of the sphere and λ is the
            wavelength in the surrounding medium. Can be a scalar or an array.
        n_pole (int):
            Multipole order to compute:
            - If 0 (default), computes contributions from all multipoles.
            - If non-zero, computes contributions from the specified multipole order.
            - A nonzero order beyond ``wiscombe_terms(x)`` raises ValueError.
        e_field (boolean):
            When n_pole>0, selects which multipole of that order contributes:
            True gives the electric multipole a_n, False the magnetic
            multipole b_n. The two add up to the full order-n_pole
            contribution for qext and qsca. Ignored when n_pole is 0.

    Returns:
        tuple:
            qext (float or array-like):
                Extinction efficiency, representing the total attenuation of light
                (scattering plus absorption) by the particle.
            qsca (float or array-like):
                Scattering efficiency, representing the fraction of incident light
                scattered by the particle.
            qback (float or array-like):
                Backscattering efficiency, describing the fraction of incident light
                scattered in the exact backward direction (theta = 180 degrees).
            g (float or array-like):
                Asymmetry parameter, representing the average cosine of the scattering
                angle over all angles. This is exactly zero when n_pole > 0, because a
                single multipole of one parity scatters symmetrically about 90 degrees.

    Notes:
        - Ensure m and x have compatible dimensions if passed as arrays.
        - For accurate results, n_pole should be within the range of significant
          multipole contributions, typically n ~ x + 4*x**(1/3).
        - This implementation assumes spherical, homogeneous particles in a
          non-absorbing medium.

    Raises:
        ValueError: if m or x is not finite, x is negative, or the real part of
            m is negative.  A perfect conductor is m.real == 0, not m.real < 0.

    Examples:
        Compute efficiencies for one sphere:

        >>> import miepython as mie
        >>> qext, qsca, qback, g = mie.efficiencies_mx(1.5 - 0.01j, 2.0)
        >>> print(f"{qext:.6f} {qsca:.6f} {qback:.6f} {g:.6f}")
        1.812597 1.724396 0.266214 0.630214

        Compute efficiencies for a wavelength-dependent refractive index:

        >>> import numpy as np
        >>> m_array = np.array([1.5 - 0.01j, 1.45 - 0.02j])
        >>> x_array = np.array([2.0, 2.5])
        >>> qext, qsca, qback, g = mie.efficiencies_mx(m_array, x_array)
        >>> np.round(qext, 6)
        array([1.812597, 2.14972 ])

        Use :func:`efficiencies` instead when the diameter and wavelength are
        known rather than the size parameter.
    """
    _check_m_x(m, x)
    m, x = _scalarize_0d(m), _scalarize_0d(x)

    # ensure imaginary part of refractive index is negative
    if np.isscalar(m):
        m = np.conj(m) if np.imag(m) > 0 else m
    else:
        m = np.where(np.imag(m) > 0, np.conj(m), m)

    mlen = 0
    if hasattr(m, "__len__"):
        mlen = len(m)

    xlen = 0
    if hasattr(x, "__len__"):
        xlen = len(x)

    if mlen == 0 and xlen == 0:
        return single_sphere(m, x, n_pole, e_field)

    if xlen > 0 and mlen > 0 and xlen != mlen:
        raise RuntimeError("m and x arrays to mie must be same length")

    thelen = max(xlen, mlen)
    qext = np.empty(thelen, dtype=np.float64)
    qsca = np.empty(thelen, dtype=np.float64)
    qback = np.empty(thelen, dtype=np.float64)
    g = np.empty(thelen, dtype=np.float64)

    mm = m
    xx = x
    for i in range(thelen):
        if mlen > 0:
            mm = m[i]

        if xlen > 0:
            xx = x[i]

        qext[i], qsca[i], qback[i], g[i] = single_sphere(mm, xx, n_pole, e_field)

    return qext, qsca, qback, g


def _mie_efficiencies(m, x):
    """Return the full Mie efficiencies, the default source for normalization."""
    return single_sphere(m, x, 0, True)


def normalization_factor(m, x, norm_str, efficiency_source=_mie_efficiencies):
    """
    Figure out scattering function normalization.

    Args:
        m: complex index of refraction of sphere
        x: dimensionless sphere size
        norm_str: string describing type of normalization
        efficiency_source: callable returning ``(qext, qsca, qback, g)`` for ``m``
            and ``x``.  Defaults to the full Mie solution; ``miepython.rayleigh``
            passes its own so that the two share these rules rather than keeping
            a second copy of them.

    Returns:
        scaling factor needed for scattering function
    """
    m, x = _scalarize_0d(m), _scalarize_0d(x)
    if np.imag(m) > 0:  # ensure imaginary part of refractive index is negative
        m = np.conj(m)
    factor = None
    norm = norm_str.lower()

    if norm in ["bohren"]:
        factor = 1 / 2

    elif norm in ["wiscombe"]:
        factor = 1

    elif norm in ["qsca", "scattering_efficiency"]:
        # a zero-size sphere has zero amplitudes, so any nonzero factor leaves
        # them zero; x * sqrt(pi) would give 0/0
        factor = x * np.sqrt(np.pi) if x > 0 else 1

    else:
        qext, qsca, _, _ = efficiency_source(m, x)

        # every remaining choice divides by qext or qsca
        if qext <= 0 or qsca <= 0:
            raise ValueError(
                "normalization %r needs a sphere that scatters, but qext=%g and qsca=%g. "
                "A sphere of zero size, or one whose index matches its surroundings, has "
                "no scattering to normalize against. Use norm='wiscombe', 'bohren' or "
                "'qsca' if an unnormalized amplitude is what you want." % (norm_str, qext, qsca)
            )

        if norm in ["a", "albedo"]:
            factor = x * np.sqrt(np.pi * qext)

        if norm in ["1", "one", "unity"]:
            factor = x * np.sqrt(qsca * np.pi)

        if norm in ["four_pi", "4pi"]:
            factor = x * np.sqrt(qsca / 4)

        if norm in ["qext", "extinction_efficiency"]:
            factor = x * np.sqrt(qsca * np.pi / qext)

    if factor is None:
        raise ValueError(
            "normalization must be one of 'albedo' (default), 'one', '4pi', 'qext', 'qsca', 'bohren', or 'wiscombe'"
        )
    return factor


def S1_S2(m, x, mu, norm="albedo", n_pole=0):
    """
    Calculate the scattering amplitude functions for spheres.

    With the default ``norm='albedo'`` the unpolarized intensity
    ``(abs(S1)**2 + abs(S2)**2)/2`` integrated over all 4*pi solid angles equals the
    single-scattering albedo qsca/qext.

    The normalization is controlled by `norm` and should be one of
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', or 'wiscombe']
    The normalization describes the integral of the scattering phase
    function over all 4𝜋 steradians.

    The units are weird, sr**(-0.5)

    Args:
        m: the complex index of refraction of the sphere
        x: the size parameter of the sphere
        mu: the angles, cos(theta), to calculate scattering amplitudes. A scalar,
            list, tuple or array is accepted; a scalar is treated as one angle,
            so the returned amplitudes are still length-one arrays.
        norm: (optional) string describing scattering function normalization
        n_pole: isolate a single multipole order, 1=dipole, 2=quadrupole,
            3=octupole (default=0 means include all terms). Summing over
            every order reproduces the full series, so n_pole uses the same
            convention as `efficiencies_mx`. Orders beyond the truncated
            series raise a ValueError.

    Returns:
        S1, S2: the scattering amplitudes at each angle mu [sr**(-0.5)].  They
        follow the active time convention: with the default exp(+jωt) they are
        Wiscombe's MIEV0 amplitudes, the conjugates of Bohren & Huffman's, and
        inside ``miepython.time_convention("-")`` they are Bohren & Huffman's.

    Raises:
        ValueError: if m or x is not finite, x is negative, or the real part of
            m is negative.  A perfect conductor is m.real == 0, not m.real < 0.
            Also if m or x is an array, since this describes one sphere.
    """
    S1, S2 = _S1_S2_normalized(m, x, mu, norm, n_pole)
    return _convert(S1), _convert(S2)


def _S1_S2_normalized(m, x, mu, norm="albedo", n_pole=0):
    """Return ``S1_S2`` in exp(-iωt), whatever the active convention."""
    _check_m_x(m, x)
    _check_one_sphere(m, x)
    m, x = _scalarize_0d(m), _scalarize_0d(x)
    if np.imag(m) > 0:  # ensure imaginary part of refractive index is negative
        m = np.conj(m)

    # The numba kernel is declared for float64[:], so a list or an integer array
    # would be rejected there while numpy accepted it.  Coercing here keeps both
    # backends callable with exactly the same arguments.
    mu_array = np.atleast_1d(np.asarray(mu, dtype=float))
    S1, S2 = _S1_S2(m, x, mu_array, n_pole)

    normalization = normalization_factor(m, x, norm)

    S1 /= normalization
    S2 /= normalization

    return S1, S2


def phase_matrix(m, x, mu, norm="albedo", n_pole=0):
    """
    Calculate the scattering (Mueller) matrix.

    If mu has length N, then the returned matrix is 4x4xN.  If mu is a scalar
    then the matrix is 4x4

    The phase scattering matrix is computed from the scattering amplitude
    functions, according to equations 5.2.105-6 in K. N. Liou (**2002**) -
    *An Introduction to Atmospheric Radiation*, Second Edition.

    or

    Bohren and Huffman, *Absorption and Scattering of Light by Small Particles*,
    JOHN WILEY & SONS, page 112, (1983).

    S11, S12 and S33 do not depend on the time convention, but S34 does, and so
    does the handedness of the Stokes V it couples to.  With exp(-iωt), inside
    ``miepython.time_convention("-")``, the matrix is Bohren & Huffman's
    eq. 3.16 with ``p[2, 3] = S34`` and ``p[3, 2] = -S34``.  With the default
    exp(+jωt) both elements change sign.

    The normalization is controlled by `norm` and should be one of
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', or 'wiscombe']
    The normalization describes the integral of the scattering phase
    function over all 4𝜋 steradians.

    Args:
        m: the complex index of refraction of the sphere
        x: the size parameter of the sphere
        mu: the angles, cos(theta), of the phase scattering matrix. Unlike the
            other angular functions this one squeezes a single angle away, so a
            scalar gives a bare 4x4 matrix rather than 4x4x1.
        n_pole: return n_pole term from series (default=0 means include all terms)
        norm: (optional) string describing scattering function normalization

    Returns:
        p: the phase scattering matrix [sr**(-1.0)]
    """
    mu = np.atleast_1d(mu)
    s1, s2 = S1_S2(m=m, x=x, mu=mu, norm=norm, n_pole=n_pole)

    s1_star = np.conjugate(s1)
    s2_star = np.conjugate(s2)
    m1 = (s1 * s1_star).real
    m2 = (s2 * s2_star).real
    s21 = (0.5 * (s1 * s2_star + s2 * s1_star)).real
    d21 = (-0.5j * (s1 * s2_star - s2 * s1_star)).real
    phase = np.zeros(shape=(4, 4, mu.size))
    phase[0, 0] = 0.5 * (m2 + m1)
    phase[0, 1] = 0.5 * (m2 - m1)
    phase[1, 0] = phase[0, 1]
    phase[1, 1] = phase[0, 0]
    phase[2, 2] = s21
    phase[2, 3] = -d21
    phase[3, 2] = d21
    phase[3, 3] = s21

    return phase.squeeze()


def i_per(m, x, mu, norm="albedo", n_pole=0):
    """
    Compute the scattered intensity for perpendicular incident light.

    This function calculates the angular distribution of the scattered intensity from a sphere
    for incident light with its electric field vector perpendicular to the scattering plane
    (the plane defined by the incident direction and the scattered direction).
    This corresponds to the :math:`|S₁(θ)|²` term in Mie theory.

    The result is normalized according to the specified method. The normalization affects
    the total integrated intensity over 4π steradians. Accepted normalization options include:
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', 'wiscombe'].

    Args:
        m (complex): Complex index of refraction of the sphere.
        x (float): Size parameter of the sphere.
        mu (array-like): Cosine of the scattering angle(s), cos(θ), for which
            intensity is desired. A scalar counts as one angle and yields a
            length-one array, not a bare number.
        norm (str, optional): Normalization method for the scattered intensity. Default is 'albedo'.
        n_pole (int, optional): If greater than zero, returns only the nth multipole term;
            default is 0, which returns the sum of all terms.

    Returns:
        np.ndarray: Scattered intensity values at each angle specified by `mu`. Units: [1/sr].
    """
    s1, _ = S1_S2(m, x, mu, norm, n_pole)
    intensity = np.abs(s1) ** 2
    return intensity.astype("float")


def i_par(m, x, mu, norm="albedo", n_pole=0):
    """
    Compute the scattered intensity for parallel incident light.

    This function calculates the angular distribution of the scattered intensity from a sphere
    for incident light with its electric field vector parallel to the scattering plane
    (the plane defined by the incident direction and the scattered direction).
    This corresponds to the :math:`|S₂(θ)|²` term in Mie theory.

    The result is normalized according to the specified method. The normalization affects
    the total integrated intensity over 4π steradians. Accepted normalization options include:
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', 'wiscombe'].

    Args:
        m (complex): Complex index of refraction of the sphere.
        x (float): Size parameter of the sphere.
        mu (array-like): Cosine of the scattering angle(s), cos(θ), for which
            intensity is desired. A scalar counts as one angle and yields a
            length-one array, not a bare number.
        norm (str, optional): Normalization method for the scattered intensity. Default is 'albedo'.
        n_pole (int, optional): If greater than zero, returns only the nth multipole term;
            default is 0, which returns the sum of all terms.

    Returns:
        np.ndarray: Scattered intensity values at each angle specified by `mu`. Units: [1/sr].
    """
    _, s2 = S1_S2(m, x, mu, norm, n_pole)
    intensity = np.abs(s2) ** 2
    return intensity.astype("float")


def i_unpolarized(m, x, mu, norm="albedo", n_pole=0):
    """
    Return the unpolarized scattered intensity at specified angles.

    The unpolarized scattering is the average of the scattered intensity for polarized
    incidence parallel to and perpendicular to the plane of scattering.

    The unpolarized scattering may also be thought of as a time average of randomly
    polarized incident light over some interval.

    The normalization describes the integral of the scattered intensity
    over all 4𝜋 steradians.  The normalization should be one of
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', or 'wiscombe']

    Args:
        m: the complex index of refraction of the sphere
        x: the size parameter
        mu: the cos(theta) of each direction desired. A scalar counts as one
            direction and yields a length-one array, not a bare number.
        norm: (optional) string describing scattering function normalization
        n_pole (int, optional): If greater than zero, returns only the nth multipole term;
            default is 0, which returns the sum of all terms.

    Returns:
        The unpolarized intensity at each angle in the array mu.  Units [1/sr]
    """
    s1, s2 = S1_S2(m, x, mu, norm, n_pole)
    intensity = (np.abs(s1) ** 2 + np.abs(s2) ** 2) / 2
    return intensity.astype("float")


def efficiencies(m, d, lambda0, n_env=1.0):
    """
    Calculate the efficiencies of a sphere.

    Args:
        m: the complex index of refraction of the sphere [-]
        d: the diameter of the sphere                    [same units as lambda0]
        lambda0: wavelength in a vacuum                  [same units as d]
        n_env: real index of medium around sphere, optional.

    Returns:
        qext: the total extinction efficiency                  [-]
        qsca: the scattering efficiency                        [-]
        qback: the backscatter efficiency                      [-]
        g: the average cosine of the scattering phase function [-]
    """
    m_env = m / n_env
    x_env = np.pi * d / (lambda0 / n_env)
    return efficiencies_mx(m_env, x_env)


def intensities(m, d, lambda0, mu, n_env=1.0, norm="albedo", n_pole=0):
    """
    Return the scattered intensities from a sphere.

    These are the scattered intensities resulting from light hitting the sphere with
    polarization parallel to or perpendicular to the plane of scattering (defined
    by the incident direction and the scattered direction).

    The scattered intensity is normalized such that the integral of the
    unpolarized intensity over 4𝜋 steradians is equal to the single scattering
    albedo.  The scattered intensity has units of inverse steradians [1/sr].

    The normalization is controlled by `norm` and should be one of
    ['albedo', 'one', '4pi', 'qext', 'qsca', 'bohren', or 'wiscombe']
    The normalization describes the integral of the scattering phase
    function over all 4𝜋 steradians.

    Args:
        m: the complex index of refraction of the sphere [-]
        d: the diameter of the sphere                    [same units as lambda0]
        lambda0: wavelength in a vacuum                  [same units as d]
        mu: the cos(theta) of each direction desired     [-]
        n_env: real index of medium around sphere, optional.
        norm: (optional) string describing scattering function normalization
        n_pole (int, optional): If greater than zero, returns only the nth multipole term;
            default is 0, which returns the sum of all terms.

    Returns:
        ipar, iper: scattered intensity in parallel and perpendicular planes [1/sr]
    """
    m_env = m / n_env
    lambda_env = lambda0 / n_env
    x_env = np.pi * d / lambda_env
    s1, s2 = S1_S2(m_env, x_env, mu, norm, n_pole)
    ipar = np.abs(s2) ** 2
    iper = np.abs(s1) ** 2
    Ipar = ipar.astype("float")
    Iper = iper.astype("float")
    return Ipar, Iper
